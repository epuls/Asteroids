This example creates an SDL window and renderer, and then draws a few
rectangles that change size each frame.

