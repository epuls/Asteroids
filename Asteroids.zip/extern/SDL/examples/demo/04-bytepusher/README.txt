An implementation of the BytePusher VM

For example programs and more information about BytePusher, see
https://esolangs.org/wiki/BytePusher
